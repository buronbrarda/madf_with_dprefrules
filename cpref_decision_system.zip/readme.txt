------------------------------------------------------------------------
				CPref Decision System Application
------------------------------------------------------------------------

** WE HAVE ONLY RUN THIS APPLICATION ON 64 BITS MACHINES RUNNING
WINDOWS 7/10 OS. SO, ALL INSTRUCTIONS ARE GIVEN CONSIDERING THIS
ARQUITECTURE.


=======================================================================
Pre-requisites
=======================================================================
1. Having installed Jave Runtime Environment 8 (64 bits) or superior.
You can download it from: https://java.com/en/download/manual.jsp

2. Having installed SWI-Prolog 7.6.0 (64 bits) or superior.
You can download it from: http://www.swi-prolog.org/download/devel

3. Add to the system path the SWI-Prolog executable folder
(Usually, you can find it as 'C:/Program Files/swipl/bin').
In the following link, there is an instrucction manual to do this:
https://docs.telerik.com/teststudio/features/test-runners/add-path-environment-variables

=======================================================================

TO LAUNCH THE APPLICATION EXECUTE app.jar.
